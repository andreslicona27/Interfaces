﻿#define DEBUG
using System.Globalization;

namespace Ejercicio_6
{
    internal class Program
    {
        public static bool Factorial(int num, ref int fact)
        {
            if (num < 0 || num > 10)
            {
                return false;
            }

            fact = 1;
            for (int i = 2; i <= num; i++)
            {
                fact *= i;
            }

            return true;

        }

        public static void Posiciones(int cantidad = 10)
        {
            int i = 0;
            Random rnd = new Random();
            while (i < cantidad)
            {
                Console.SetCursorPosition(rnd.Next(1, 21), rnd.Next(1, 11));
                Console.Write("*");
                i++;

            }

        }

        static void Main(string[] args)
        {
#if DEBU

            int n = -11;
            int n2 = 0;
            bool numFactorial;
            numFactorial = Factorial(n, ref n2);

            if (numFactorial)
            {
                Console.WriteLine(String.Format("El factorial de {0} es: {1}", n, n2));

            }

#else
            Posiciones();

#endif
            Console.ReadKey();

        }
    }
}