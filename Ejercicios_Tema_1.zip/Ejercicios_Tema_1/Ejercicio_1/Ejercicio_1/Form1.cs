namespace Ejercicio_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
         
          
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                double num1 = double.Parse(textBox1.Text);
                double num2 = double.Parse(textBox2.Text);

                double suma = num1 + num2;

                label2.Text = "= " + suma.ToString();

            }
            catch (Exception)
            {
                label2.Text = "= Solo se admiten n�meros";
            }

        }
    }
}