#define DEBUG
using System.ComponentModel;

namespace Ejercicio_3
{
    public partial class Form1 : Form
    {
        int credito = 50;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random generador = new Random();

            textBox1.Text = generador.Next(1, 8).ToString();
            textBox2.Text = generador.Next(1, 8).ToString();
            textBox3.Text = generador.Next(1, 8).ToString();

            credito -= 2;
            label2.Text = String.Format("Credito : {0}", credito);

            if (textBox1.Text == textBox2.Text && textBox3.Text == textBox1.Text)
            {
                label2.Text = String.Format("Credito : {0}", credito + 20);
                credito += 20;
                label1.Text = "Premio de 20 euros";

            }
            else if (textBox1.Text == textBox2.Text || textBox1.Text == textBox3.Text || textBox2.Text == textBox3.Text)
            {
#if DEBUG
                credito += 5;
                label1.Text = "Premio de 5 euros";
#else
                credito -= 5;
                label1.Text = "Se restan 5 euros";
#endif
                label2.Text = String.Format("Credito : {0}", credito);
            }
            else
            {
                label1.Text = "No hay premio";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            credito = credito + 10;
            label2.Text = String.Format("Credito : {0}", credito);
            label1.Text = "Tienes 10 euros extra";
        }
    }
}