﻿using System.IO.IsolatedStorage;

namespace Ejercicio_4
{
    internal class Program
    {
        public static void TirarDado()
        {
            Random generador = new Random();
            string? numCaras;
            string? numAcertar;

            Console.WriteLine("Dame el número de caras");
            numCaras = Console.ReadLine();
            Console.WriteLine("¿Qué número deseas acertar?");
            numAcertar = Console.ReadLine();

            while (int.Parse(numAcertar) < 1 || int.Parse(numAcertar) > int.Parse(numCaras))
            {
                Console.WriteLine("Número fuera de rango, intenta de nuevo");
                Console.WriteLine("¿Qué número deseas acertar?");
                numAcertar = Console.ReadLine();
            }

            int aciertos = 0;
            for (int i = 1; i <= 10; i++)
            {
                int numAleatorio = generador.Next(1, int.Parse(numCaras) + 1);
                Console.WriteLine(String.Format("Tirada {0}: {1}", i, numAleatorio));

                if ((numAleatorio.ToString()).Equals(numAcertar))
                {
                    aciertos++;
                }

            }
            Console.WriteLine(String.Format("\nHas acertado {0} veces\n", aciertos));
        }

        public static void AdivinaNumero()
        {
            Random generador = new Random();
            int numAle;
            int intentos = 5;
            string? numJug;
            bool ganaste = false;

            numAle = generador.Next(1, 101);
            //Console.Write(numAle + "\n");
            while (intentos != 0)
            {
                Console.Write("Dame un número: ");
                numJug = Console.ReadLine();

                while (int.Parse(numJug) < 1 || int.Parse(numJug) > 100)
                {
                    Console.WriteLine("Número fuera de rango, intenta de nuevo");
                    Console.WriteLine("Dame un número: ");
                    numJug = Console.ReadLine();
                }

                if (int.Parse(numJug) == numAle)
                {
                    intentos = 0;
                    ganaste = true;

                }
                else if (int.Parse(numJug) < numAle)
                {
                    Console.Write("Ese numero es menor al que debes adivinar\n");
                    intentos--;
                    Console.WriteLine(String.Format("Tienes {0} intentos\n", intentos));
                }
                else
                {
                    Console.Write("Ese numero es mayor al que debes adivinar\n");
                    intentos--;
                    Console.WriteLine(String.Format("Tienes {0} intentos\n", intentos));
                }
            }
            if (ganaste)
            {
                Console.WriteLine("¡Felicidades Acertaste!\n");
            }
            else
            {
                Console.WriteLine(String.Format("¡Perdiste! El numero era {0}\n", numAle));
            }

        }

        public static char Quiniela()
        {
            char var1 = '1';
            char var2 = '2';
            char var3 = 'X';

            Random generador = new Random();
            int resultado = generador.Next(1, 101);

            switch (resultado)
            {
                case <= 60:
                    return var1;

                case >= 61 and <= 85:
                    return var3;

                default:
                    return var2;
            }

        }
        public static string RepetirJuego()
        {
            string? opc;

            Console.WriteLine("¿Deseas repetir el juego?\n" +
                        "1.) Si\n" +
                        "2.) No\n");
            opc = Console.ReadLine();
            return opc;
        }


        static void Main(string[] args)
        {
            string? opcion;
            bool vengoDeCase4 = false;
            do
            {
                Console.WriteLine("\nMENU DE OPCIONES\n" +
                    "1.) Tirar Dado\n" +
                    "2.) Adivina un número\n" +
                    "3.) Realizar una quiniela\n" +
                    "4.) Jugar a todos\n" +
                    "5.) Salir\n");
                opcion = Console.ReadLine();

                switch (int.Parse(opcion))
                {
                    case 1:
                        string? opcDado;
                        do
                        {
                            Console.WriteLine("Juego del Dado\n");
                            TirarDado();
                            opcDado = RepetirJuego();

                        } while (opcDado.Equals("1"));

                        if (vengoDeCase4)
                        {
                            goto case 2;
                        }
                        break;

                    case 2:
                        string? opcNumero;
                        do
                        {
                            Console.WriteLine("Juego de Adivina un número\n");
                            AdivinaNumero();
                            opcNumero = RepetirJuego();

                        } while (opcNumero.Equals("1"));

                        if (vengoDeCase4)
                        {
                            goto case 3;
                        }
                        break;

                    case 3:
                        string? opcQuiniela;
                        do
                        {
                            Console.WriteLine("Inicio de la quiniela\n");
                            for (int i = 1; i <= 14; i++)
                            {
                                Console.WriteLine(String.Format("Partido {0}: {1}", i, Quiniela()));
                            }
                            Console.WriteLine("Fin de la quiniela\n");
                            opcQuiniela = RepetirJuego();

                        } while (opcQuiniela.Equals("1"));
                        break;

                    case 4:
                        vengoDeCase4 = true;
                        goto case 1;

                    case 5:
                        break;
                }

            } while (int.Parse(opcion) != 5);

        }

    }

}