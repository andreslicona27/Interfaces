namespace Ejercicio_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult a;

            a = MessageBox.Show(
                "�Quieres poner " + textBox1.Text + " como titulo?",
                "Message Box",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
                ); ;

            if(a == DialogResult.Yes)
            {
                Text = textBox1.Text;
            }
        }

    }
}